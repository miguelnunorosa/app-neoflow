import 'dart:ui';

const APP_PRIMARY_COLOR = Color(0xFF3A3735);